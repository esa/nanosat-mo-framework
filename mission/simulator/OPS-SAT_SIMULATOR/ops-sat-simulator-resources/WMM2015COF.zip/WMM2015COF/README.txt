World Magnetic Model WMM2015
=======================================================
Date December 15, 2014

WMM.COF					WMM2015 Coefficients file
						(May be replaced with old WMM.COF (WMM2010) file)



Model Software Support
======================

*  National Geophysical Data Center
*  NOAA EGC/2
*  325 Broadway
*  Boulder, CO 80303 USA
*  Attn: Manoj Nair or Arnaud Chulliat
*  Phone:  (303) 497-4642 or -6522
*  Email:  geomag.models@noaa.gov
For more details about the World Magnetic Model visit 
http://www.ngdc.noaa.gov/geomag/WMM/DoDWMM.shtml
 




       
